@echo off
setlocal enabledelayedexpansion
echo.
echo  =========================================
echo   RhythmBeast - Windows EXE Builder
echo  =========================================
echo.

:: Refresh PATH from registry (picks up freshly installed Node)
for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "SYSPATH=%%B"
for /f "tokens=2*" %%A in ('reg query "HKCU\Environment" /v Path 2^>nul') do set "USERPATH=%%B"
set "PATH=%SYSPATH%;%USERPATH%"

:: Also check common Node install locations
if exist "C:\Program Files\nodejs\node.exe"       set "PATH=C:\Program Files\nodejs;%PATH%"
if exist "C:\Program Files (x86)\nodejs\node.exe" set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
if exist "%APPDATA%\nvm\current\node.exe"          set "PATH=%APPDATA%\nvm\current;%PATH%"

:: Find node
node --version >nul 2>&1
if errorlevel 1 (
    echo  ERROR: Node.js not found.
    echo.
    echo  It may not be on PATH yet after installing.  Try:
    echo    1. Restart your PC then run BUILD.bat again
    echo    2. Or play now by double-clicking RhythmBeast.html
    echo.
    pause
    exit /b 1
)
for /f %%v in ('node --version') do echo  Node.js: %%v

echo.
echo [1/2] Installing Electron (downloads ~120MB on first run)...
call npm install
if errorlevel 1 ( echo  npm install failed. & pause & exit /b 1 )

echo.
echo [2/2] Building EXE...
call npm run build
if errorlevel 1 ( echo  Build failed. & pause & exit /b 1 )

echo.
echo  =========================================
echo   Done!  dist\RhythmBeast.exe is ready.
echo  =========================================
explorer dist
pause
