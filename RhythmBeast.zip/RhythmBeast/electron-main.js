const { app, BrowserWindow, shell } = require('electron');
const path = require('path');

// Keep a global reference so the window isn't garbage collected
let mainWindow;

function createWindow() {
    mainWindow = new BrowserWindow({
        width:     740,
        height:    980,
        minWidth:  580,
        minHeight: 720,
        title:     'RhythmBeast',
        backgroundColor: '#0f0c29',   // match game background — no white flash on load
        show: false,                  // don't show until ready-to-show fires
        webPreferences: {
            nodeIntegration:  false,
            contextIsolation: true,
            webSecurity:      false,  // required for ES modules + audio from file://
        },
    });

    // Remove the default menu bar (File, Edit, View…)
    mainWindow.setMenuBarVisibility(false);

    // Load the game
    mainWindow.loadFile(path.join(__dirname, 'game', 'index.html'));

    // Show window only once content is rendered — avoids white flash
    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
    });

    // Open external links in the real browser, not in-app
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        shell.openExternal(url);
        return { action: 'deny' };
    });

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

app.whenReady().then(() => {
    createWindow();

    // macOS: re-create window when dock icon is clicked and no windows open
    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

// Quit when all windows are closed (Windows / Linux behaviour)
app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});
