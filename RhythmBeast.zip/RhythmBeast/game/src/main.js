import { Game } from './game.js';
import { Menu } from './menu.js';
import { AudioManager } from './audio.js';
import { STATE } from './states.js';

class GameController {
    constructor() {
        this.canvas    = document.getElementById('gameCanvas');
        this.ctx       = this.canvas.getContext('2d');
        this.visCanvas = document.getElementById('visualizerCanvas');
        this.visCtx    = this.visCanvas.getContext('2d');

        this.audio = new AudioManager();
        this.menu  = new Menu(this.audio);
        this.game  = new Game(this.ctx, this.visCtx, this.audio, this.menu);

        // When menu finishes loading audio it calls this callback
        this.menu.setStartCallback(() => this._launchGame());

        window.addEventListener('keydown', e => this._onKey(e));

        document.addEventListener('visibilitychange', () => {
            if (document.hidden && this.game.state === STATE.PLAYING) {
                this.game.pause();
            }
        });

        this._startLoop();
    }

    /* ── Key handler ────────────────────────────────────────────── */
    _onKey(e) {
        const state = this.game.state;

        if (e.code === 'Space') {
            e.preventDefault();
            if (state === STATE.PLAYING) return; // ignore Space during play
            // Route through the menu's full start flow (loads audio, then launches)
            this.menu.triggerStart();
            return;
        }

        if (state === STATE.PLAYING) {
            if (e.key.startsWith('Arrow')) {
                e.preventDefault();
                this.game.snake?.handleInput(e.key);
            }
            if (e.code === 'Escape') {
                e.preventDefault();
                this.game.pause();
            }
        }
    }

    /* ── Called by menu after audio has successfully loaded ─────── */
    _launchGame() {
        this.menu.hide();

        // game.start() is async — catch errors and show them in the page
        this.game.start().catch(err => {
            console.error('Game start error:', err);
            this._showFatalError(err.message || 'Could not start game.');
            this.menu.show();
        });
    }

    /* ── In-page error (no alert — blocked in Edge app mode) ───── */
    _showFatalError(msg) {
        let el = document.getElementById('fatal-error');
        if (!el) {
            el = document.createElement('div');
            el.id = 'fatal-error';
            el.style.cssText = [
                'position:fixed', 'top:16px', 'left:50%', 'transform:translateX(-50%)',
                'background:#7f1d1d', 'color:#fca5a5', 'border:1.5px solid #ef4444',
                'border-radius:8px', 'padding:12px 20px', 'font-size:14px',
                'z-index:9999', 'max-width:480px', 'text-align:center',
                'box-shadow:0 4px 20px rgba(0,0,0,0.5)',
            ].join(';');
            document.body.appendChild(el);
        }
        el.textContent  = `⚠️  ${msg}`;
        el.style.display = 'block';
        clearTimeout(this._errTimer);
        this._errTimer = setTimeout(() => { el.style.display = 'none'; }, 8000);
    }

    /* ── Game loop ──────────────────────────────────────────────── */
    _startLoop() {
        let last = 0;
        const tick = (now) => {
            const dt = Math.min(now - last, 100);
            last = now;
            try {
                this.game.loop(dt);
            } catch (err) {
                console.error('Loop error:', err);
                this._showFatalError('An error occurred. Please reload.');
            }
            requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    }
}

// Boot
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => new GameController());
} else {
    new GameController();
}
