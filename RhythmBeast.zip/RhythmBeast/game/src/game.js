import { STATE } from './states.js';
import { Snake } from './snake.js';
import { Visualizer } from './visualizer.js';
import { Particles } from './particles.js';

export class Game {
    constructor(ctx, visCtx, audioManager, menu) {
        this.ctx          = ctx;
        this.visCtx       = visCtx;
        this.audioManager = audioManager;
        this.menu         = menu;

        this.state    = STATE.IDLE;
        this.score    = 0;
        this.combo    = 0;
        this.maxCombo = 0;
        this.isPaused = false;
        this.beatFlash = 0;

        this.snake      = new Snake();
        this.visualizer = new Visualizer(visCtx, audioManager);
        this.particles  = new Particles(ctx);

        this._init();
    }

    _init() {
        this.audioManager.on('beat',  () => this._onBeat());
        this.audioManager.on('ended', () => this.endGame());
        window.addEventListener('snakeDied',  () => this.endGame());
        window.addEventListener('appleEaten', (e) => {
            if (e.detail?.score !== undefined) this.score = e.detail.score;
            this.combo++;
            if (this.combo > this.maxCombo) this.maxCombo = this.combo;
        });
    }

    /* ── Start — async so we can properly await audio.play() ───── */
    async start() {
        if (this.state === STATE.PLAYING) return;
        this.reset();
        this.state    = STATE.PLAYING;
        this.isPaused = false;

        const diff = this.menu.getDifficulty();
        this.snake.setDifficulty(diff);
        this.snake.setScoreMultiplier(this.menu.getDifficultyMultiplier());

        // Await play so AudioContext.resume() completes before we return
        await this.audioManager.play();
    }

    /* ── Pause / resume ─────────────────────────────────────────── */
    async pause() {
        if (this.state !== STATE.PLAYING) return;
        this.isPaused = !this.isPaused;
        if (this.isPaused) {
            this.audioManager.pause();
        } else {
            await this.audioManager.resume();
        }
    }

    reset() {
        this.score = 0; this.combo = 0; this.maxCombo = 0; this.beatFlash = 0;
        this.snake.reset();
        this.particles.clear();
    }

    loop(dt) {
        if (!this.isPaused) this._update(dt);
        this._render();
    }

    _update(dt) {
        if (this.state !== STATE.PLAYING) return;
        this.snake.update(dt, this.audioManager);
        this.visualizer.update();
        this.particles.update(dt);
        this.score     = this.snake.getScore();
        this.beatFlash = Math.max(0, this.beatFlash - dt * 0.008);
        if (this.audioManager.isEnded()) this.endGame();
    }

    _render() {
        const ctx = this.ctx;
        const W = ctx.canvas.width, H = ctx.canvas.height;

        ctx.fillStyle = '#1a1a2e';
        ctx.fillRect(0, 0, W, H);

        if (this.beatFlash > 0) {
            ctx.fillStyle = `rgba(14,165,233,${this.beatFlash * 0.07})`;
            ctx.fillRect(0, 0, W, H);
        }

        if (this.state === STATE.PLAYING || this.isPaused) {
            this.particles.render();
            this.snake.render(ctx);
            this.visualizer.render();
            this._renderHUD();
            if (this.isPaused) this._renderPause();
        } else if (this.state === STATE.GAME_OVER) {
            this._renderGameOver();
        }
    }

    _renderHUD() {
        const ctx = this.ctx;
        const W   = ctx.canvas.width;

        ctx.font      = 'bold 22px "Segoe UI", Arial';
        ctx.textAlign = 'left';
        ctx.fillStyle = '#fff';
        ctx.shadowBlur   = 8;
        ctx.shadowColor  = 'rgba(14,165,233,0.6)';
        ctx.fillText(`Score: ${this.score}`, 16, 36);
        ctx.shadowBlur   = 0;

        if (this.combo >= 2) {
            const col = this._comboColor();
            ctx.font       = 'bold 18px "Segoe UI", Arial';
            ctx.fillStyle  = col;
            ctx.shadowBlur  = 10;
            ctx.shadowColor = col;
            ctx.fillText(`x${this.combo} COMBO`, 16, 60);
            ctx.shadowBlur  = 0;
        }

        const dConf = { easy:'#22c55e', medium:'#eab308', hard:'#f97316', insane:'#ef4444' };
        ctx.font      = 'bold 13px "Segoe UI", Arial';
        ctx.textAlign = 'right';
        ctx.fillStyle = dConf[this.menu.getDifficulty()] ?? '#fff';
        ctx.fillText(this.menu.getDifficulty().toUpperCase(), W - 14, 36);
        ctx.textAlign = 'left';
    }

    _renderPause() {
        const ctx = this.ctx;
        const W = ctx.canvas.width, H = ctx.canvas.height;
        ctx.fillStyle = 'rgba(0,0,0,0.72)';
        ctx.fillRect(0, 0, W, H);
        ctx.fillStyle   = '#fff';
        ctx.font        = 'bold 52px "Segoe UI", Arial';
        ctx.textAlign   = 'center';
        ctx.shadowBlur  = 20;
        ctx.shadowColor = '#0ea5e9';
        ctx.fillText('PAUSED', W/2, H/2);
        ctx.shadowBlur  = 0;
        ctx.font        = '20px "Segoe UI", Arial';
        ctx.fillStyle   = '#94a3b8';
        ctx.fillText('Press ESC to resume', W/2, H/2 + 46);
    }

    _renderGameOver() {
        const ctx = this.ctx;
        const W = ctx.canvas.width, H = ctx.canvas.height;
        const cx = W/2, cy = H/2;

        ctx.fillStyle = '#1a1a2e';
        ctx.fillRect(0, 0, W, H);
        ctx.textAlign = 'center';

        ctx.font        = 'bold 60px "Segoe UI", Arial';
        ctx.fillStyle   = '#ef4444';
        ctx.shadowBlur  = 28;
        ctx.shadowColor = '#ef4444';
        ctx.fillText('GAME OVER', cx, cy - 70);
        ctx.shadowBlur  = 0;

        ctx.font      = 'bold 34px "Segoe UI", Arial';
        ctx.fillStyle = '#fff';
        ctx.fillText(`Score: ${this.score}`, cx, cy - 10);

        ctx.font      = '22px "Segoe UI", Arial';
        ctx.fillStyle = '#fbbf24';
        ctx.fillText(`Best Combo: x${this.maxCombo}`, cx, cy + 32);

        const hs    = this.menu.getHighScore();
        const isNew = this.score >= hs && this.score > 0;
        ctx.font      = '18px "Segoe UI", Arial';
        ctx.fillStyle = isNew ? '#22c55e' : '#94a3b8';
        ctx.fillText(isNew ? '🏆 NEW HIGH SCORE!' : `High Score: ${hs}`, cx, cy + 64);

        ctx.font      = '17px "Segoe UI", Arial';
        ctx.fillStyle = '#64748b';
        ctx.fillText('SPACE to play again', cx, cy + 108);
    }

    _onBeat() {
        this.beatFlash = 1;
        this.particles.spawnBeatParticles();
    }

    endGame() {
        if (this.state === STATE.GAME_OVER) return;
        this.state = STATE.GAME_OVER;
        this.audioManager.stop();
        if (this.combo > this.maxCombo) this.maxCombo = this.combo;
        const isNew = this.menu.saveHighScore(this.score);
        if (isNew) this.menu.updateHighScoreDisplay(this.score);
        setTimeout(() => {
            if (this.state === STATE.GAME_OVER) this.menu.show();
        }, 2800);
    }

    _comboColor() {
        if (this.combo >= 30) return '#ff00ff';
        if (this.combo >= 20) return '#ef4444';
        if (this.combo >= 10) return '#f97316';
        if (this.combo >=  5) return '#eab308';
        return '#22c55e';
    }

    destroy() {
        this.audioManager.stop();
        this.particles.clear();
    }
}
