export class Snake {
    constructor() {
        this.gridSize   = 15;
        this.cellSize   = 40;
        this.colorHue   = 180;
        this.beatPulse  = 0;
        this.animTime   = 0;
        this.scoreMultiplier = 1;

        this.eatAnimTimer    = 0;
        this.lastEatenPos    = null;
        this.moveProgress    = 0;
        this.prevSegments    = [];

        this.reset();
    }

    reset() {
        const c = Math.floor(this.gridSize / 2);
        this.segments    = [{ x: c, y: c }];
        this.direction   = { x: 0, y: 0 };
        this.inputQueue  = [];
        this.speed       = 115;
        this.moveTimer   = 0;
        this.moveProgress = 0;
        this.prevSegments = [];
        this.score       = 0;
        this.apples      = [];
        this.isAlive     = true;
        this.blinkTimer  = 0;
        this.beatPulse   = 0;

        const count = 2 + Math.floor(Math.random() * 2);
        for (let i = 0; i < count; i++) this.apples.push(this._spawnApple());
    }

    setDifficulty(level) {
        const speeds = { easy: 180, medium: 115, hard: 70, insane: 38 };
        this.speed = speeds[level] ?? 115;
    }

    setScoreMultiplier(m) { this.scoreMultiplier = m; }

    /* ── Apple spawning ──────────────────────────────────────── */
    _spawnApple() {
        for (let t = 0; t < 120; t++) {
            const p = {
                x: Math.floor(Math.random() * this.gridSize),
                y: Math.floor(Math.random() * this.gridSize),
            };
            const hit = this.segments.some(s => s.x === p.x && s.y === p.y)
                     || this.apples.some(a => a.x === p.x && a.y === p.y);
            if (!hit) return p;
        }
        return { x: 0, y: 0 };
    }

    /* ── Input ───────────────────────────────────────────────── */
    handleInput(key) {
        if (!this.isAlive) return;
        const map = { ArrowUp:{x:0,y:-1}, ArrowDown:{x:0,y:1}, ArrowLeft:{x:-1,y:0}, ArrowRight:{x:1,y:0} };
        const nd = map[key]; if (!nd) return;
        const last = this.inputQueue.length ? this.inputQueue[this.inputQueue.length-1] : this.direction;
        if (last.x !== 0 && nd.x === -last.x) return;
        if (last.y !== 0 && nd.y === -last.y) return;
        if (this.inputQueue.length < 3) this.inputQueue.push(nd);
    }

    /* ── Update ──────────────────────────────────────────────── */
    update(dt, audioManager) {
        if (!this.isAlive) return;
        this.animTime  += dt * 0.001;
        this.blinkTimer += dt;
        if (this.eatAnimTimer > 0) this.eatAnimTimer -= dt;
        this.colorHue = (this.colorHue + dt * 0.025) % 360;
        this.beatPulse = Math.max(0, this.beatPulse - dt * 0.004);

        if (audioManager?.detectBeat()) this.beatPulse = 0.35;

        this.moveTimer   += dt;
        this.moveProgress = Math.min(1, this.moveTimer / this.speed);
        if (this.moveTimer >= this.speed) {
            this.moveTimer = 0;
            this.moveProgress = 0;
            this._move();
        }
    }

    _move() {
        this.prevSegments = this.segments.map(s => ({...s}));
        if (this.inputQueue.length) this.direction = this.inputQueue.shift();
        if (!this.direction.x && !this.direction.y) return;

        const head = this.segments[0];
        const nh = {
            x: (head.x + this.direction.x + this.gridSize) % this.gridSize,
            y: (head.y + this.direction.y + this.gridSize) % this.gridSize,
        };

        // Self collision
        for (let i = 1; i < this.segments.length; i++) {
            if (this.segments[i].x === nh.x && this.segments[i].y === nh.y) {
                this._die(); return;
            }
        }

        // Apple collision
        let ate = false;
        for (let i = 0; i < this.apples.length; i++) {
            if (this.apples[i].x === nh.x && this.apples[i].y === nh.y) {
                this._eatApple(i); ate = true; break;
            }
        }

        this.segments.unshift(nh);
        if (!ate) this.segments.pop();
    }

    _eatApple(i) {
        const points = Math.round(10 * this.scoreMultiplier);
        this.score  += points;
        this.lastEatenPos   = { ...this.apples[i] };
        this.eatAnimTimer   = 350;
        this.apples.splice(i, 1);
        this.apples.push(this._spawnApple());
        window.dispatchEvent(new CustomEvent('appleEaten', {
            detail: { position: this.lastEatenPos, score: this.score, points }
        }));
    }

    _die() {
        this.isAlive = false;
        window.dispatchEvent(new CustomEvent('snakeDied', { detail: { score: this.score } }));
    }

    /* ── Render ──────────────────────────────────────────────── */
    render(ctx) {
        ctx.save();
        this._drawSnake(ctx);
        this._drawApples(ctx);
        if (this.eatAnimTimer > 0 && this.lastEatenPos) this._drawEatEffect(ctx);
        ctx.restore();
    }

    _drawSnake(ctx) {
        const cs = this.cellSize;
        this.segments.forEach((seg, i) => {
            let x = seg.x * cs, y = seg.y * cs;
            if (this.prevSegments[i]) {
                const p  = this.prevSegments[i];
                let dx   = x - p.x * cs;
                let dy   = y - p.y * cs;
                const maxD = (this.gridSize * cs) / 2;
                if (Math.abs(dx) > maxD) dx += dx > 0 ? -this.gridSize * cs : this.gridSize * cs;
                if (Math.abs(dy) > maxD) dy += dy > 0 ? -this.gridSize * cs : this.gridSize * cs;
                x = p.x * cs + dx * this.moveProgress;
                y = p.y * cs + dy * this.moveProgress;
            }

            const hue  = (this.colorHue + i * 4) % 360;
            const glow = i === 0 ? 12 + this.beatPulse * 20 : 6;
            const col  = `hsl(${hue},85%,${50 - i * 0.4}%)`;

            ctx.fillStyle  = col;
            ctx.shadowBlur = glow;
            ctx.shadowColor = col;

            const pad  = 2;
            const r    = i === 0 ? 9 : 6;
            this._roundRect(ctx, x + pad, y + pad, cs - pad*2, cs - pad*2, r);
            ctx.fill();

            // Eyes on head
            if (i === 0) {
                ctx.shadowBlur = 0;
                ctx.fillStyle  = 'rgba(0,0,0,0.85)';
                const es = (cs - 4) * 0.14;
                ctx.beginPath();
                ctx.arc(x + (cs-4)*0.3 + pad, y + (cs-4)*0.33 + pad, es, 0, Math.PI*2);
                ctx.arc(x + (cs-4)*0.7 + pad, y + (cs-4)*0.33 + pad, es, 0, Math.PI*2);
                ctx.fill();
                // Eye shine
                ctx.fillStyle = 'rgba(255,255,255,0.6)';
                ctx.beginPath();
                ctx.arc(x + (cs-4)*0.3 + pad - es*0.3, y + (cs-4)*0.33 + pad - es*0.3, es*0.45, 0, Math.PI*2);
                ctx.arc(x + (cs-4)*0.7 + pad - es*0.3, y + (cs-4)*0.33 + pad - es*0.3, es*0.45, 0, Math.PI*2);
                ctx.fill();
            }
        });
        ctx.shadowBlur = 0;
    }

    _drawApples(ctx) {
        this.apples.forEach((apple, i) => {
            const x = apple.x * this.cellSize + this.cellSize / 2;
            const y = apple.y * this.cellSize + this.cellSize / 2;
            const pulse  = Math.sin(this.blinkTimer * 0.005 + i * 1.1) * 0.18 + 0.82;
            const radius = (this.cellSize / 2 - 5) * pulse;

            ctx.shadowBlur  = 22;
            ctx.shadowColor = '#ff6699';
            ctx.fillStyle   = '#ff0044';
            ctx.beginPath();
            ctx.arc(x, y, radius, 0, Math.PI * 2);
            ctx.fill();

            ctx.shadowBlur  = 0;
            ctx.fillStyle   = 'rgba(255,255,255,0.45)';
            ctx.beginPath();
            ctx.arc(x - radius * 0.28, y - radius * 0.28, radius * 0.28, 0, Math.PI * 2);
            ctx.fill();
        });
    }

    _drawEatEffect(ctx) {
        const prog = 1 - (this.eatAnimTimer / 350);
        const x = this.lastEatenPos.x * this.cellSize + this.cellSize / 2;
        const y = this.lastEatenPos.y * this.cellSize + this.cellSize / 2;
        const r = (this.cellSize / 2) * (1 + prog * 2.5);
        ctx.strokeStyle = `rgba(255,220,0,${1 - prog})`;
        ctx.lineWidth   = 3;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.stroke();
    }

    _roundRect(ctx, x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y,     x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h,     x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y,         x + r, y);
        ctx.closePath();
    }

    getScore()   { return this.score; }
    isGameOver() { return !this.isAlive; }
}
