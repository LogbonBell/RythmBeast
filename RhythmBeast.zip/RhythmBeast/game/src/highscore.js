const STORAGE_KEY = 'rhythmbeast_v2_scores';

export class HighScoreManager {
    constructor() {
        this._scores = this._load();
    }

    _load() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);
            return raw ? JSON.parse(raw) : {};
        } catch { return {}; }
    }

    _save() {
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(this._scores)); }
        catch(e) { console.warn('HighScore save failed', e); }
    }

    _key(songName, difficulty) {
        return `${(songName || 'unknown').toLowerCase().trim()}__${difficulty}`;
    }

    /** Returns true if score is a new record. */
    submit(songName, difficulty, score) {
        const key = this._key(songName, difficulty);
        const prev = this._scores[key] ?? 0;
        if (score > prev) {
            this._scores[key] = score;
            this._save();
            return true;
        }
        return false;
    }

    get(songName, difficulty) {
        return this._scores[this._key(songName, difficulty)] ?? 0;
    }

    getAll() { return { ...this._scores }; }

    clear() { this._scores = {}; this._save(); }
}
