export const STATE = Object.freeze({
    IDLE:      'idle',
    PLAYING:   'playing',
    PAUSED:    'paused',
    GAME_OVER: 'game_over',
    ERROR:     'error',
});

export const DIFFICULTY = Object.freeze({
    EASY:   'easy',
    MEDIUM: 'medium',
    HARD:   'hard',
    INSANE: 'insane',
});

export const DIFFICULTY_CONFIG = Object.freeze({
    easy:   { snakeSpeed: 180, scoreMultiplier: 1.0,  label: 'Easy',   color: '#22c55e' },
    medium: { snakeSpeed: 115, scoreMultiplier: 1.5,  label: 'Medium', color: '#eab308' },
    hard:   { snakeSpeed:  70, scoreMultiplier: 2.0,  label: 'Hard',   color: '#f97316' },
    insane: { snakeSpeed:  38, scoreMultiplier: 3.5,  label: 'Insane', color: '#ef4444' },
});
