export class Visualizer {
    constructor(ctx, audioManager) {
        this.ctx          = ctx;
        this.audioManager = audioManager;
        this.canvas       = ctx.canvas;
        this.barCount     = 32;
        this.barWidth     = this.canvas.width / this.barCount;
        this.colors       = {
            primary:   [14,  165, 233],
            secondary: [139,  92, 246],
            accent:    [236,  72, 153],
        };
        this.smoothed     = new Array(this.barCount).fill(0);
        this.smooth       = 0.78;
        this.animTime     = 0;
    }

    update() {
        const data = this.audioManager.getFrequencyData();
        if (data) {
            for (let i = 0; i < this.barCount; i++) {
                const idx = Math.floor((i / this.barCount) * data.length);
                const v   = data[idx] || 0;
                this.smoothed[i] = this.smoothed[i] * this.smooth + v * (1 - this.smooth);
            }
        }
        this.animTime += 0.016;
    }

    render() {
        const { width, height } = this.canvas;
        const bg = this.ctx.createLinearGradient(0, 0, 0, height);
        bg.addColorStop(0, '#1a1a2e');
        bg.addColorStop(1, '#16213e');
        this.ctx.fillStyle = bg;
        this.ctx.fillRect(0, 0, width, height);

        for (let i = 0; i < this.barCount; i++) {
            const x   = i * this.barWidth;
            const n   = this.smoothed[i] / 255;
            const bh  = Math.max(2, n * height * 0.95);
            const y   = height - bh;
            this._drawCube(x, y, this.barWidth - 3, bh, i / this.barCount, n);
        }
        this.ctx.shadowBlur = 0;
    }

    _drawCube(x, y, w, h, progress, intensity) {
        const depth = w * 0.38;
        const top   = depth * 0.6;
        const front = this._gradColor(progress, intensity);
        const light = this._lighten(front, 0.28);
        const dark  = this._darken(front, 0.28);

        if (intensity > 0.65) {
            this.ctx.shadowBlur  = 14 * intensity;
            this.ctx.shadowColor = front;
        }

        this.ctx.fillStyle = front;
        this.ctx.fillRect(x, y, w, h);

        this.ctx.fillStyle = light;
        this.ctx.beginPath();
        this.ctx.moveTo(x, y);
        this.ctx.lineTo(x + top, y - top);
        this.ctx.lineTo(x + w + top, y - top);
        this.ctx.lineTo(x + w, y);
        this.ctx.closePath(); this.ctx.fill();

        this.ctx.fillStyle = dark;
        this.ctx.beginPath();
        this.ctx.moveTo(x + w, y);
        this.ctx.lineTo(x + w + top, y - top);
        this.ctx.lineTo(x + w + top, y + h - top);
        this.ctx.lineTo(x + w, y + h);
        this.ctx.closePath(); this.ctx.fill();

        this.ctx.shadowBlur = 0;
    }

    _gradColor(p, intensity) {
        let r, g, b;
        const lerp = (a,b,t) => a + (b-a)*t;
        if (p < 0.5) {
            const t = p * 2;
            r = lerp(this.colors.primary[0], this.colors.secondary[0], t);
            g = lerp(this.colors.primary[1], this.colors.secondary[1], t);
            b = lerp(this.colors.primary[2], this.colors.secondary[2], t);
        } else {
            const t = (p - 0.5) * 2;
            r = lerp(this.colors.secondary[0], this.colors.accent[0], t);
            g = lerp(this.colors.secondary[1], this.colors.accent[1], t);
            b = lerp(this.colors.secondary[2], this.colors.accent[2], t);
        }
        const boost = 1 + intensity * 0.4;
        return `rgb(${Math.min(255,Math.floor(r*boost))},${Math.min(255,Math.floor(g*boost))},${Math.min(255,Math.floor(b*boost))})`;
    }

    _lighten(c, f) {
        const m = c.match(/\d+/g);
        if (!m) return c;
        return `rgb(${Math.min(255,+m[0]+255*f|0)},${Math.min(255,+m[1]+255*f|0)},${Math.min(255,+m[2]+255*f|0)})`;
    }
    _darken(c, f) {
        const m = c.match(/\d+/g);
        if (!m) return c;
        return `rgb(${(+m[0]*(1-f))|0},${(+m[1]*(1-f))|0},${(+m[2]*(1-f))|0})`;
    }
}
