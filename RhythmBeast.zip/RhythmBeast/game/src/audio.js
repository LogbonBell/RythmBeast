export class AudioManager {
    constructor() {
        this.audioContext  = null;
        this.audioElement  = null;
        this.source        = null;
        this.analyser      = null;
        this.gainNode      = null;
        this.dataArray     = null;

        this.isPlaying     = false;
        this.isLoaded      = false;

        this.listeners     = new Map();

        // Beat detection
        this.beatCooldown  = 0;
        this.beatThreshold = 1.35;
    }

    /* ── Init AudioContext (must happen after a user gesture) ─── */
    async init() {
        if (this.audioContext) return;
        this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        this.analyser     = this.audioContext.createAnalyser();
        this.analyser.fftSize               = 256;
        this.analyser.smoothingTimeConstant = 0.8;
        this.gainNode     = this.audioContext.createGain();
        this.gainNode.gain.value = 0.8;
        this.dataArray    = new Uint8Array(this.analyser.frequencyBinCount);
    }

    /* ── Load from file ────────────────────────────────────────── */
    async loadFromFile(file) {
        await this.init();
        const arrayBuffer = await file.arrayBuffer();
        await this._connect(arrayBuffer);
    }

    /* ── Load from URL ─────────────────────────────────────────── */
    async loadFromUrl(url) {
        await this.init();

        // Block YouTube links early with a clear message
        if (/youtube\.com|youtu\.be/i.test(url)) {
            throw new Error(
                'YouTube links cannot be loaded directly.\n' +
                'Download the audio file first (e.g. using yt-dlp), then upload it.'
            );
        }

        let res;
        try {
            res = await fetch(url);
        } catch {
            throw new Error('Could not fetch that URL. Check the link and try again.');
        }
        if (!res.ok) throw new Error(`Server returned ${res.status} for that URL.`);

        const contentType = res.headers.get('content-type') || '';
        if (!contentType.startsWith('audio/') && !contentType.startsWith('video/')) {
            throw new Error(
                `That URL does not point to an audio file (got: ${contentType}).\n` +
                'Make sure it is a direct link to an MP3, WAV, or OGG file.'
            );
        }

        const arrayBuffer = await res.arrayBuffer();
        await this._connect(arrayBuffer);
    }

    /* ── Connect array buffer → Web Audio graph ────────────────── */
    async _connect(arrayBuffer) {
        // Tear down old source if any
        if (this.source) {
            try { this.source.disconnect(); } catch (_) {}
            this.source = null;
        }
        if (this.audioElement) {
            this.audioElement.pause();
            this.audioElement.removeAttribute('src');
            this.audioElement.load();
        }

        // Build an object URL so the <audio> element can stream it
        const blob = new Blob([arrayBuffer]);
        const blobUrl = URL.createObjectURL(blob);

        const audio = new Audio();
        audio.preload = 'auto';
        audio.src = blobUrl;

        // Wait until the browser can play it
        await new Promise((res, rej) => {
            const onReady = () => { cleanup(); res(); };
            const onError = (e) => { cleanup(); rej(new Error(`Audio decode error: ${e.message || e}`)); };
            const cleanup = () => {
                audio.removeEventListener('canplaythrough', onReady);
                audio.removeEventListener('error', onError);
            };
            audio.addEventListener('canplaythrough', onReady, { once: true });
            audio.addEventListener('error', onError,        { once: true });
            audio.load();
        });

        this.audioElement = audio;

        // Wire into Web Audio graph
        this.source = this.audioContext.createMediaElementSource(this.audioElement);
        this.source.connect(this.analyser);
        this.analyser.connect(this.gainNode);
        this.gainNode.connect(this.audioContext.destination);

        this.audioElement.addEventListener('ended', () => {
            this.isPlaying = false;
            this.emit('ended');
        });

        this.isLoaded = true;
        this.emit('loaded');
    }

    /* ── Playback ──────────────────────────────────────────────── */
    async play() {
        if (!this.isLoaded || !this.audioElement) {
            throw new Error('No audio loaded');
        }

        // Resume AudioContext — this MUST be awaited before playing
        if (this.audioContext.state === 'suspended') {
            await this.audioContext.resume();
        }

        // audioElement.play() returns a Promise — await it so errors surface
        await this.audioElement.play();
        this.isPlaying = true;
        this.emit('play');
    }

    pause() {
        if (!this.audioElement) return;
        this.audioElement.pause();
        this.isPlaying = false;
        this.emit('pause');
    }

    async resume() {
        if (!this.audioElement) return;
        if (this.audioContext.state === 'suspended') {
            await this.audioContext.resume();
        }
        await this.audioElement.play();
        this.isPlaying = true;
        this.emit('resume');
    }

    stop() {
        if (!this.audioElement) return;
        this.audioElement.pause();
        this.audioElement.currentTime = 0;
        this.isPlaying = false;
        this.emit('stop');
    }

    isEnded()        { return this.audioElement?.ended ?? false; }
    getCurrentTime() { return this.audioElement?.currentTime ?? 0; }
    getDuration()    { return this.audioElement?.duration    ?? 0; }

    setVolume(v) {
        if (this.gainNode) this.gainNode.gain.value = Math.max(0, Math.min(1, v));
    }

    /* ── Frequency / beat ──────────────────────────────────────── */
    getFrequencyData() {
        if (this.analyser && this.isPlaying) {
            this.analyser.getByteFrequencyData(this.dataArray);
        }
        return this.dataArray;
    }

    detectBeat() {
        if (!this.isPlaying || this.beatCooldown > 0) {
            if (this.beatCooldown > 0) this.beatCooldown--;
            return false;
        }
        const data = this.getFrequencyData();
        if (!data) return false;

        let bassSum = 0;
        for (let i = 0; i < 6; i++) bassSum += data[i];
        const bass = bassSum / 6;

        let total = 0;
        for (let i = 0; i < data.length; i++) total += data[i];
        const avg = (total / data.length) || 1;

        if (bass > avg * this.beatThreshold && bass > 30) {
            this.beatCooldown = 12;
            this.emit('beat', { strength: bass / avg });
            return true;
        }
        return false;
    }

    /* ── Event bus ─────────────────────────────────────────────── */
    on(event, cb) {
        if (!this.listeners.has(event)) this.listeners.set(event, []);
        this.listeners.get(event).push(cb);
    }
    off(event, cb) {
        const arr = this.listeners.get(event);
        if (!arr) return;
        const i = arr.indexOf(cb);
        if (i > -1) arr.splice(i, 1);
    }
    emit(event, data) {
        this.listeners.get(event)?.forEach(cb => { try { cb(data); } catch (_) {} });
    }

    destroy() {
        this.stop();
        try { this.source?.disconnect(); }    catch (_) {}
        try { this.audioContext?.close(); }   catch (_) {}
        this.listeners.clear();
    }
}
