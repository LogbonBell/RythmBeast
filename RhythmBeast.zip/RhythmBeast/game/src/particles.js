export class Particles {
    constructor(ctx) {
        this.ctx = ctx;
        this.particles = [];
        this.maxParticles = 200;
        
        // Listen for apple eaten events
        window.addEventListener('appleEaten', (e) => {
            const { position } = e.detail;
            if (position) {
                this.spawnAppleParticles(position.x, position.y);
            }
        });
    }

    update(deltaTime) {
        // Update all particles
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];
            
            // Update position
            particle.x += particle.vx * (deltaTime / 16);
            particle.y += particle.vy * (deltaTime / 16);
            
            // Apply gravity
            particle.vy += particle.gravity * (deltaTime / 16);
            
            // Apply drag
            particle.vx *= particle.drag;
            particle.vy *= particle.drag;
            
            // Update life
            particle.life -= deltaTime;
            particle.alpha = Math.max(0, particle.life / particle.maxLife);
            
            // Update size
            particle.size *= particle.shrink;
            
            // Remove dead particles
            if (particle.life <= 0 || particle.size < 0.5) {
                this.particles.splice(i, 1);
            }
        }
    }

    render() {
        this.particles.forEach(particle => {
            this.ctx.save();
            
            // Set alpha
            this.ctx.globalAlpha = particle.alpha;
            
            // Draw particle based on type
            if (particle.type === 'circle') {
                this.ctx.fillStyle = particle.color;
                this.ctx.beginPath();
                this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                this.ctx.fill();
                
                // Add glow
                if (particle.glow) {
                    this.ctx.shadowBlur = 10;
                    this.ctx.shadowColor = particle.color;
                }
            } else if (particle.type === 'square') {
                this.ctx.fillStyle = particle.color;
                this.ctx.fillRect(
                    particle.x - particle.size / 2,
                    particle.y - particle.size / 2,
                    particle.size,
                    particle.size
                );
            } else if (particle.type === 'star') {
                this.drawStar(particle.x, particle.y, particle.size, particle.color);
            }
            
            this.ctx.restore();
        });
        
        // Reset shadow
        this.ctx.shadowBlur = 0;
    }

    drawStar(x, y, size, color) {
        const spikes = 5;
        const outerRadius = size;
        const innerRadius = size / 2;
        
        this.ctx.fillStyle = color;
        this.ctx.beginPath();
        
        for (let i = 0; i < spikes * 2; i++) {
            const radius = i % 2 === 0 ? outerRadius : innerRadius;
            const angle = (i * Math.PI) / spikes;
            const xPos = x + Math.cos(angle) * radius;
            const yPos = y + Math.sin(angle) * radius;
            
            if (i === 0) {
                this.ctx.moveTo(xPos, yPos);
            } else {
                this.ctx.lineTo(xPos, yPos);
            }
        }
        
        this.ctx.closePath();
        this.ctx.fill();
    }

    spawn(x, y, config = {}) {
        if (this.particles.length >= this.maxParticles) {
            return;
        }
        
        const particle = {
            x,
            y,
            vx: config.vx || (Math.random() - 0.5) * 4,
            vy: config.vy || (Math.random() - 0.5) * 4,
            size: config.size || 5,
            color: config.color || '#ffffff',
            life: config.life || 1000,
            maxLife: config.life || 1000,
            alpha: 1,
            gravity: config.gravity || 0.1,
            drag: config.drag || 0.98,
            shrink: config.shrink || 0.99,
            type: config.type || 'circle',
            glow: config.glow !== undefined ? config.glow : true
        };
        
        this.particles.push(particle);
    }

    spawnAppleParticles(gridX, gridY) {
        const cellSize = 40; // Match snake cell size
        const centerX = gridX * cellSize + cellSize / 2;
        const centerY = gridY * cellSize + cellSize / 2;
        
        // Spawn burst of particles
        const count = 15;
        for (let i = 0; i < count; i++) {
            const angle = (i / count) * Math.PI * 2;
            const speed = 3 + Math.random() * 2;
            
            this.spawn(centerX, centerY, {
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: 4 + Math.random() * 4,
                color: this.getRandomColor(['#ff0044', '#ff6699', '#ffaa00', '#ffff00']),
                life: 500 + Math.random() * 500,
                gravity: 0.05,
                drag: 0.97,
                shrink: 0.98,
                type: Math.random() > 0.7 ? 'star' : 'circle',
                glow: true
            });
        }
    }

    spawnBeatParticles() {
        // Spawn particles from random edges on beat
        const canvas = this.ctx.canvas;
        const side = Math.floor(Math.random() * 4);
        let x, y, vx, vy;
        
        switch (side) {
            case 0: // Top
                x = Math.random() * canvas.width;
                y = 0;
                vx = (Math.random() - 0.5) * 2;
                vy = 2 + Math.random() * 2;
                break;
            case 1: // Right
                x = canvas.width;
                y = Math.random() * canvas.height;
                vx = -(2 + Math.random() * 2);
                vy = (Math.random() - 0.5) * 2;
                break;
            case 2: // Bottom
                x = Math.random() * canvas.width;
                y = canvas.height;
                vx = (Math.random() - 0.5) * 2;
                vy = -(2 + Math.random() * 2);
                break;
            case 3: // Left
                x = 0;
                y = Math.random() * canvas.height;
                vx = 2 + Math.random() * 2;
                vy = (Math.random() - 0.5) * 2;
                break;
        }
        
        this.spawn(x, y, {
            vx,
            vy,
            size: 3 + Math.random() * 3,
            color: this.getRandomColor(['#00ffff', '#0088ff', '#8b5cf6']),
            life: 1000 + Math.random() * 1000,
            gravity: 0,
            drag: 0.99,
            shrink: 0.995,
            type: 'circle',
            glow: true
        });
    }

    spawnTrail(x, y, color) {
        this.spawn(x, y, {
            vx: (Math.random() - 0.5) * 1,
            vy: (Math.random() - 0.5) * 1,
            size: 3,
            color: color || '#ffffff',
            life: 300,
            gravity: 0,
            drag: 0.95,
            shrink: 0.96,
            type: 'circle',
            glow: false
        });
    }

    getRandomColor(colors) {
        return colors[Math.floor(Math.random() * colors.length)];
    }

    clear() {
        this.particles = [];
    }

    getCount() {
        return this.particles.length;
    }
}