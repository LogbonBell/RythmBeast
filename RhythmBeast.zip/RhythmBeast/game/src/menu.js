import { DIFFICULTY_CONFIG } from './states.js';
import { HighScoreManager } from './highscore.js';

export class Menu {
    constructor(audioManager) {
        this.audioManager = audioManager;
        this.highScores   = new HighScoreManager();

        // DOM refs
        this.menuEl        = document.getElementById('menu');
        this.songInput     = document.getElementById('songInput');
        this.urlInput      = document.getElementById('urlInput');
        this.diffSelect    = document.getElementById('difficultySelect');
        this.startBtn      = document.getElementById('startButton');
        this.volumeSlider  = document.getElementById('volumeSlider');
        this.volumeLabel   = document.getElementById('volumeLabel');
        this.infoBar       = document.getElementById('info-bar');
        this.songNameEl    = document.getElementById('song-name');
        this.highScoreEl   = document.getElementById('high-score');
        this.progressBar   = document.getElementById('progress-bar');
        this.progressTime  = document.getElementById('progress-time');

        // State
        this.selectedFile = null;
        this.selectedUrl  = null;
        this.songName     = '';
        this.difficulty   = 'medium';
        this._visible     = true;
        this.startCb      = null;
        this._progressId  = null;
        this._loading     = false;

        this._init();
    }

    get isVisible() { return this._visible; }

    /* ── Setup ─────────────────────────────────────────────────── */
    _init() {
        // File picker
        this.songInput.addEventListener('change', e => {
            const file = e.target.files[0];
            if (!file) { this.selectedFile = null; this._updateBtn(); return; }
            if (!this._validAudio(file)) {
                this._showError('Invalid file type. Please use MP3, WAV, OGG, M4A or FLAC.');
                this.songInput.value = '';
                return;
            }
            if (file.size > 100 * 1024 * 1024) {
                this._showError('File is too large (max 100 MB).');
                this.songInput.value = '';
                return;
            }
            this.selectedFile = file;
            this.selectedUrl  = null;
            this.urlInput.value = '';
            this.songName = file.name.replace(/\.[^/.]+$/, '');
            this._hideError();
            this._updateBtn();
        });

        // URL input
        this.urlInput.addEventListener('input', () => {
            setTimeout(() => {
                const url = this.urlInput.value.trim();
                if (url) {
                    this.selectedUrl  = url;
                    this.selectedFile = null;
                    this.songInput.value = '';
                    try {
                        const p = new URL(url).pathname;
                        this.songName = decodeURIComponent(p.split('/').pop().replace(/\.[^/.]+$/, '')) || 'Stream';
                    } catch { this.songName = 'Audio Stream'; }
                    this._hideError();
                } else {
                    this.selectedUrl = null;
                    this.songName    = '';
                }
                this._updateBtn();
            }, 10);
        });

        // Difficulty
        this.diffSelect.addEventListener('change', e => {
            this.difficulty = e.target.value;
        });

        // Volume
        this.volumeSlider.addEventListener('input', () => {
            const v = parseInt(this.volumeSlider.value, 10);
            this.volumeLabel.textContent = `${v}%`;
            this.audioManager.setVolume(v / 100);
        });

        // Start button
        this.startBtn.addEventListener('click', () => this.triggerStart());

        // Enter on URL field
        this.urlInput.addEventListener('keydown', e => {
            if (e.key === 'Enter') { e.preventDefault(); this.triggerStart(); }
        });
    }

    /* ── Public: trigger the full load → start flow ────────────── */
    triggerStart() {
        if (this._loading) return;          // already loading
        if (!this._canStart()) {
            this._showError('Select an audio file or enter a direct audio URL first.');
            return;
        }
        this._setLoading(true);

        this._loadAudio()
            .then(() => {
                // Audio loaded — fire the callback (wired up in main.js)
                if (this.startCb) this.startCb();
            })
            .catch(err => {
                this._setLoading(false);
                // Show the error inside the menu (never use alert — it's blocked in app mode)
                this._showError(err.message || 'Failed to load audio. Check the file or URL.');
            });
    }

    async _loadAudio() {
        if (this.selectedFile) {
            await this.audioManager.loadFromFile(this.selectedFile);
        } else if (this.selectedUrl) {
            await this.audioManager.loadFromUrl(this.selectedUrl);
        } else {
            throw new Error('No audio source selected.');
        }
        this.audioManager.setVolume(parseInt(this.volumeSlider.value, 10) / 100);
    }

    /* ── Visibility ────────────────────────────────────────────── */
    show() {
        this.menuEl.classList.remove('hidden');
        this._visible = true;
        this._setLoading(false);
        this.infoBar.classList.add('hidden');
        this._stopProgress();
    }

    hide() {
        this.menuEl.classList.add('hidden');
        this._visible = false;
        this.infoBar.classList.remove('hidden');
        if (this.songNameEl) this.songNameEl.textContent = this.songName || '—';
        this._updateHighScoreDisplay();
        this._startProgress();
    }

    /* ── Progress bar (runs while playing) ─────────────────────── */
    _startProgress() {
        this._stopProgress();
        this._progressId = setInterval(() => {
            const cur = this.audioManager.getCurrentTime();
            const dur = this.audioManager.getDuration();
            if (dur > 0) {
                this.progressBar.style.width = `${(cur / dur) * 100}%`;
                this.progressTime.textContent = `${this._fmt(cur)} / ${this._fmt(dur)}`;
            }
        }, 500);
    }
    _stopProgress() {
        if (this._progressId) { clearInterval(this._progressId); this._progressId = null; }
        if (this.progressBar)  this.progressBar.style.width = '0%';
        if (this.progressTime) this.progressTime.textContent = '0:00 / 0:00';
    }
    _fmt(s) {
        const m   = Math.floor(s / 60);
        const sec = String(Math.floor(s % 60)).padStart(2, '0');
        return `${m}:${sec}`;
    }

    /* ── High scores ────────────────────────────────────────────── */
    saveHighScore(score) {
        return this.highScores.submit(this.songName, this.difficulty, score);
    }
    getHighScore() {
        return this.highScores.get(this.songName, this.difficulty);
    }
    _updateHighScoreDisplay() {
        if (this.highScoreEl) this.highScoreEl.textContent = this.getHighScore();
    }
    updateHighScoreDisplay(score) {
        if (this.highScoreEl) this.highScoreEl.textContent = score;
    }

    /* ── Getters ────────────────────────────────────────────────── */
    getDifficulty()  { return this.difficulty; }
    getSongName()    { return this.songName; }
    getDifficultyMultiplier() {
        return DIFFICULTY_CONFIG[this.difficulty]?.scoreMultiplier ?? 1;
    }

    /* ── Helpers ────────────────────────────────────────────────── */
    setStartCallback(cb) { this.startCb = cb; }

    _canStart() { return !!(this.selectedFile || this.selectedUrl); }

    _updateBtn() {
        const ok = this._canStart();
        this.startBtn.disabled = !ok;
        this.startBtn.textContent = ok
            ? `▶  Start  —  ${this.songName || 'Selected'}`
            : 'Select a song to start';
    }

    _setLoading(on) {
        this._loading = on;
        this.startBtn.disabled        = on || !this._canStart();
        this.startBtn.textContent     = on ? '⏳  Loading audio…' : (this._canStart() ? `▶  Start  —  ${this.songName}` : 'Select a song to start');
        this.songInput.disabled       = on;
        this.urlInput.disabled        = on;
        this.diffSelect.disabled      = on;
        this.volumeSlider.disabled    = on;
    }

    _validAudio(file) {
        const types = [
            'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/wave',
            'audio/ogg', 'audio/mp4', 'audio/x-m4a', 'audio/aac', 'audio/flac',
            'video/mp4',  // some browsers label m4a as video/mp4
        ];
        const exts = ['.mp3', '.wav', '.ogg', '.m4a', '.aac', '.flac', '.mp4'];
        return types.includes(file.type) || exts.some(e => file.name.toLowerCase().endsWith(e));
    }

    /* ── Error display (never uses alert()) ─────────────────────── */
    _showError(msg) {
        let el = document.getElementById('menu-error');
        if (!el) {
            el = document.createElement('div');
            el.id = 'menu-error';
            this.menuEl.insertBefore(el, this.startBtn.nextSibling);
        }
        el.textContent    = `⚠️  ${msg}`;
        el.style.display  = 'block';
        clearTimeout(this._errTimer);
        this._errTimer = setTimeout(() => this._hideError(), 8000);
    }
    _hideError() {
        const el = document.getElementById('menu-error');
        if (el) el.style.display = 'none';
    }

    destroy() { this._stopProgress(); this.startCb = null; }
}
