# ⚽ RhythmBeast

A rhythm-based snake game. Upload any MP3/WAV/OGG and play to the beat.

---

## Building the Windows EXE

### Requirements
- **Node.js** (free) — https://nodejs.org → click the green "LTS" button

### Steps
1. Install Node.js (one-time, then done forever)
2. Double-click **BUILD.bat**
3. Wait ~3 minutes (downloads Electron on first run)
4. Your game appears at **`dist\RhythmBeast.exe`**

That single `.exe` file is self-contained. Copy it anywhere, share it, run it — no installation needed.

---

## How to play
- Upload an **MP3, WAV, OGG, M4A or FLAC** file — or paste a direct audio URL
- YouTube links **won't work** (use yt-dlp to download first)
- Arrow keys to move the snake
- Eat apples in time with the beat
- ESC to pause, SPACE to start

---

## Notes
- High scores are saved automatically
- The first time you run BUILD.bat it downloads ~120MB (Electron) — subsequent builds are fast
